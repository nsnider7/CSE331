Name: Nicholas Snider

Feedback: Good refresher of classes. Once I understood hwo everything worked it went well.

Time Took: 9 hours

Resources:
- Zybooks Chapter 19 Sections 19.5 - 19.7
