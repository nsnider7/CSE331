lst = [[1], [2], [3]]
new_lst = sum(lst)
print(new_lst)