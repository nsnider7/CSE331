Name: Nicholas Snider
Time: ~ 10 Hours
Feedback: Recursion was difficult to get used to. Debugger was my best friend in learning though.
Sources Used:
 - https://www.geeksforgeeks.org/reverse-string-python-5-different-ways/
