"""
PROJECT 3 - Quick/Insertion Sort
Name:
PID:
"""


from InsertionSort import insertion_sort
from DoublyLinkedList import DLLNode


def quick_sort(dll, start, end, size, threshold):
    if size <= threshold and size > 1:
        insertion_sort(dll, start, end)
        return
    else:
        if size < 2:
            return
        # returns (pivot node, size from start to pivot)
        tup = partition(start, end)
        if tup[0] == None:
            return
        start = tup[0]
        while (start != None):
            if start.get_next() == None:
                dll.set_tail(start)
            start = start.get_next()

    rhand_size = 0
    val= tup[0].get_next()
    while (val != None):
        rhand_size+=1
        val = val.get_next()



    quick_sort(dll, dll.get_head(), tup[0].get_previous(), tup[1]-1, threshold)
    quick_sort(dll, tup[0].get_next(), dll.get_tail(), rhand_size, threshold)


def partition(low, high):
    pivot = high
    curNode = low
    size = 0
    while (low != None):
        size+=1
        low = low.get_next()
        if low == pivot:
            size += 1
            break
    while curNode != None and high != None:
        # If curNode great than pivot value
        if curNode.get_value() > high.get_value():
            tempNode = DLLNode(curNode.get_value())
            tempNode.set_next(high.get_next())
            tempNode.set_previous(high)
            # if first node to add to end
            if high.get_next() == None:
                high.set_next(tempNode)
            # if second node to append, change the next values previous value
            else:
                high.get_next().set_previous(tempNode)
                high.set_next(tempNode)
            # # if last node
            if curNode.get_next() == None:
                curNode.get_previous().set_next(None)
                curNode = None
            # If first node
            elif curNode.get_previous() == None:
                curNode.set_value(curNode.get_next().get_value())
                curNode.set_next(curNode.get_next().get_next())
                curNode.get_next().set_previous(curNode)
            # if middle node
            elif curNode.get_previous().get_value() != None:
                curNode.get_previous().set_next(curNode.get_next())
                curNode.get_next().set_previous(curNode.get_previous())
                curNode = curNode.get_next()
        # if next value equals the pivot
        elif curNode.get_next() == high or curNode == high:
            break
        else:
            curNode = curNode.get_next()
    # get the size from start to pivot
    return (high, size)

