Name: Nicholas Snider

Hours to complete project: 25

Feedback: Very difficult

External Sources (Attributions):