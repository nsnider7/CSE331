Name:

Hours to complete project:

Feedback:

External Sources (Attributions):
 - https://www.tutorialspoint.com/data_structures_algorithms/tree_traversal.htm
 I used this to understand each traversal. Understanding them let me then put the words into code

 -