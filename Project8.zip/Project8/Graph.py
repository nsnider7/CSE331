"""
Name:
PID:
"""

import random


def generate_edges(size, connectedness):
    """
    DO NOT EDIT THIS METHOD
    Generates undirected edges between vertices to form a graph
    :return: A generator object that returns a tuple of the form (source ID, destination ID)
    used to construct an edge
    """
    assert connectedness <= 1
    random.seed(10)
    for i in range(size):
        for j in range(i + 1, size):
            if random.randrange(0, 100) <= connectedness * 100:
                w = random.randint(1, 20)
                yield [i, j, w]


class Graph:
    """
    Class representing a Graph
    """

    class Edge:
        """
        Class representing an Edge in the Graph
        """

        __slots__ = ['start', 'destination', 'weight']

        def __init__(self, start, destination, weight):
            """
            DO NOT EDIT THIS METHOD
            :param start: represents the starting vertex of the edge
            :param destination: represents the destination vertex of the edge
            :param weight: represents the weight of the edge
            """
            self.start = start
            self.destination = destination
            self.weight = weight

        def __eq__(self, other):
            """
            DO NOT EDIT THIS METHOD
            :param other: edge to compare
            :return: Bool, True if same, otherwise False
            """
            return self.start == other.start and \
                   self.destination.vertex_id == other.destination.vertex_id \
                   and self.weight == other.weight

        def __repr__(self):
            return f"Start: {self.start} Destination: {self.destination} Weight: {self.weight}"

        __str__ = __repr__

        def get_start(self):
            return self.start

        def get_destination(self):
            return self.destination.vertex_id

        def get_weight(self):
            return self.weight

    class Vertex:
        """
        Class representing an Edge in the Graph
        """

        __slots__ = ['vertex_id', 'edges', 'visited']

        def __init__(self, vertex_id):
            """
            DO NOT EDIT THIS METHOD
            :param vertex_id: represents the unique identifier of the vertex
            """
            self.vertex_id = vertex_id
            self.edges = {}  # destination ID to edge object
            self.visited = False

        def __eq__(self, other):
            """
            DO NOT EDIT THIS METHOD
            :param other: vertex to compare
            :return: Bool, True if the same, False otherwise
            """
            return self.vertex_id == other.vertex_id and \
                   self.edges == other.edges and self.visited == other.visited

        def __repr__(self):
            return f"Vertex: {self.vertex_id}"

        __str__ = __repr__

        def degree(self):
            return len(self.edges)

        def visit(self):
            self.visited = True

        def insert_edge(self, destination, weight):
            """
            Adds an edge representation into the edge map between the vertex and the given
            :param destination:
            :param weight:
            :return:
            """
            # # check to see if current vertex and destination already have edge
            if self.get_edge(destination.vertex_id) is not None:  # includes error checking
                e = self.get_edge(destination.vertex_id)
                e.weight = weight
            self.edges[destination.vertex_id] = Graph.Edge(self.vertex_id, destination, weight)


        def get_edge(self, destination):
            if destination in self.edges:
                return self.edges[destination]
            else:
                return None

        def get_edges(self):
            edge_list = []
            for e in self.edges.values():
                edge_list.append(e)
            return edge_list

    def __init__(self):
        """
        DO NOT EDIT THIS METHOD
        """
        self.adj_map = {}
        self.size = 0

    def __eq__(self, other):
        """
        DO NOT EDIT THIS METHOD
        Determines if 2 graphs are Identical
        :param other: Graph Object
        :return: Bool, True if Graph objects are equal
        """
        return self.adj_map == other.adj_map and self.size == other.size

    def add_to_graph(self, source, dest=None, weight=0):
        """
        Inserts a vertex into the graph and will create an edge if a destination and weight
        are provided. If the source or destination vertex does not exist in the graph then one will be created.
        :param source:
        :param dest:
        :param weight:
        :return:
        """
        source_vertex = self.Vertex(source)
        # if there is a element in the dest parameter
        if dest is not None:
            # if they are both already in graph but want new edge
            if source in self.adj_map and dest in self.adj_map:
                source_vertex = self.adj_map[source]
                dest_vertex = self.adj_map[dest]
                source_vertex.insert_edge(dest_vertex, weight)
                dest_vertex.insert_edge(source_vertex, weight)

            # if source and destination are not in map
            elif dest not in self.adj_map and source not in self.adj_map:
                dest_vertex = self.Vertex(dest)
                source_vertex = self.Vertex(source)
                source_vertex.insert_edge(dest_vertex, weight)
                dest_vertex.insert_edge(source_vertex, weight)
                self.adj_map[dest] = dest_vertex
                self.adj_map[source] = source_vertex
                self.size += 2

            # if source is in map and we are mapping to do new destination
            elif source in self.adj_map and dest not in self.adj_map:
                dest_vertex = self.Vertex(dest)
                source_vertex = self.adj_map[source]
                dest_vertex.insert_edge(source_vertex, weight)
                source_vertex.insert_edge(dest_vertex, weight)
                self.adj_map[dest] = dest_vertex
                self.size += 1

            # if source is not in map and we are mapping to existing destination
            else:
                source_vertex = self.Vertex(source)
                dest_vertex = self.adj_map[dest]
                source_vertex.insert_edge(dest_vertex, weight)
                dest_vertex.insert_edge(source_vertex, weight)
                self.adj_map[source] = source_vertex
                self.size += 1

        # if source in map and destination not provided
        else:
            self.adj_map[source] = source_vertex
            self.size += 1

    def construct_graph_from_file(self, filename):
        """
        A line in the file could also have just a source or it could have a source and destination,
        but no weight. Make sure that if the sources/destinations are integers that they are converted to integers properly
        :param filename:
        :return:
        """
        file = open(filename, "r+")
        test_lst = []
        for i in file:

            i = i.split()

            test_lst.append(i)

        for i in test_lst:
            if i:
                if len(i) == 1:
                    if isinstance(i[0], str) and i[0].isdigit():
                        self.add_to_graph(int(i[0]))
                    else:
                        self.add_to_graph(i[0])
                elif len(i) == 2:
                    # both are integers
                    if (isinstance(i[0], str) and i[0].isdigit()) and (isinstance(i[1], str) and i[1].isdigit()):
                        self.add_to_graph(int(i[0]), int(i[1]))
                    # dest is an integer
                    elif isinstance(i[1], str) and i[1].isdigit():
                        self.add_to_graph(i[0], int(i[1]))
                    # src is an integer
                    elif isinstance(i[0], str) and i[0].isdigit():
                        self.add_to_graph(int(i[0]), i[1])
                elif len(i) == 3:
                    self.add_to_graph(i[0], i[1], int(i[2]))
        file.close()


    def get_vertex(self, vertex_id):
        return self.adj_map[vertex_id]

    def get_vertices(self):
        # adj_map is vertex_id:vertex
        vertex_list = []
        for key, val in self.adj_map.items():
            vertex_list.append(val)
        return vertex_list

    def bfs(self, start, target, path=None):
        start_vertex = self.get_vertex(start)
        frontierQueue = []
        frontierQueue.append([start_vertex])
        # path_lst.append(start_vertex.vertex_id)
        while frontierQueue:
            currentpath = frontierQueue.pop()
            currentV = currentpath[-1]
            currentV.visit()
            if currentV.vertex_id == target:
                return [i.vertex_id for i in currentpath]
            for edge in currentV.get_edges():
                copy_path = currentpath.copy()
                if self.get_vertex(edge.get_destination()).visited is False:
                    copy_path.append(self.get_vertex(edge.get_destination()))
                    frontierQueue.append(copy_path)


    # def BFS(self, start, discovered):
    #     """Perform BFS of the undiscovered portion of Graph g starting at Vertex s.
    #
    #     discovered is a dictionary mapping each vertex to the edge that was used to
    #     discover it during the BFS (s should be mapped to None prior to the call).
    #     Newly discovered vertices will be added to the dictionary as a result.
    #     """
    #     # print(start)
    #     level = [self.get_vertex(start)]  # first level includes only s
    #     print(level[0].get_edges())
    #     while len(level) > 0:
    #         next_level = []  # prepare to gather newly found vertices
    #         for u in level:
    #             for e in u.get_edges():  # for every outgoing edge from u
    #                 v = e.get_destination()
    #                 if v not in discovered:  # v is an unvisited vertex
    #                     discovered[v] = e  # e is the tree edge that discovered v
    #                     next_level.append(v)  # v will be further considered in next pass
    #         level = next_level  # relabel 'next' level to become current
    #
    # def BFS_complete(self):
    #     """Perform BFS for entire graph and return forest as a dictionary.
    #
    #     Result maps each vertex v to the edge that was used to discover it.
    #     (vertices that are roots of a BFS tree are mapped to None).
    #     """
    #     forest = {}
    #     for u in self.get_vertices():
    #         if u.vertex_id not in forest:
    #             forest[u.vertex_id] = None  # u will be a root of a tree
    #             self.BFS(u.vertex_id, forest)
    #     return forest


    def dfs(self, start, target, path=None):
        pass


def quickest_route(filename, start, destination):
    pass
