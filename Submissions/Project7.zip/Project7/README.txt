Name: Nicholas Snider

Hours to complete project: 8 hours

Feedback: Great project that helped familiarize myself with hash tables. Without it I wouldn't have fully grasped
the concept.

External Sources (Attributions):
 - hash_map_base.py lecture code used for rehash
 - Zybooks, 23.1, 23.5